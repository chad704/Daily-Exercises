package com.example.demo.domain;

import javax.persistence.Entity;

@Entity
public class CarDealership {

    private String make;
    private String model;

    public String getMake() {
        return make;
    }
    public void setMake(String make){
        this.make=make;
    }

    public String getModel() {
        return model;
    }
    public void setModel(String model) {
        this.model = model;
    }

    private CarDealership(){

    }

    @Override
    public String toString() {
        return "CarDealership{" +
                "make='" + make + '\'' +
                ", model='" + model + '\'' +
                '}';
    }

    public CarDealership(String make, String model){
        this.make=make;
        this.model=model;
    }
}
