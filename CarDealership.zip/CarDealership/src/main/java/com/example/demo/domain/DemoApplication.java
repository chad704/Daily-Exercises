package com.example.demo.domain;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import com.example.demo.domain.CarDealership;
import com.example.demo.domain.CarRepository;
import org.springframework.context.annotation.Bean;

public class DemoApplication {

    private static final Logger log = LoggerFactory.getLogger(DemoApplication.class);

    public static void main(String[] args) {SpringApplication.run(DemoApplication .class,args);}

    @Bean
    public CommandLineRunner demo(CarRepository repository){
        return args ->

        repository.save(new CarDealership("Honda","Civic"));
        repository.save(new CarDealership("Toyota","Tacoma"));
        repository.save(new CarDealership("BMW","M3"));
    }

}
