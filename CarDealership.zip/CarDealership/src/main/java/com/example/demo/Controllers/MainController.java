package com.example.demo.Controllers;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

    @RestController

    public class MainController {

        @RequestMapping("/") //annotation that provides "routing" info. Tells Spring that any http request with "/" path should be mapped to the home() method
        public String home(){ //because of RestController annotation Spring renders resulting string directly back to the caller. In this case is home method and string is returned
            return "Car guys are just horse girls.";
        }
    }

}
